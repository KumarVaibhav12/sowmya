import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import{LoginComponent} from './login/login.component'
import{ForgotpwdComponent} from './forgotpwd/forgotpwd.component';
import{ChangepwdComponent} from './changepwd/changepwd.component'


const routes: Routes = [

 { path: 'ForgotPassword', component: ForgotpwdComponent},
 { path: 'loginComponent', component: LoginComponent},
 { path:'',redirectTo:'loginComponent', pathMatch:'full' },
  {path: 'ChangePassword', component: ChangepwdComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
