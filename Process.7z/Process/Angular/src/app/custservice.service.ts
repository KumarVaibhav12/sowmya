import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './customer';
import { Product } from './Product'


@Injectable({
  providedIn: 'root'
})
export class CustserviceService {
  id: number;


  constructor(private httpClient: HttpClient) { }
  login(uName, pwd): Observable<number> {
    let url = 'http://localhost:9002/login/' + uName + '/' + pwd;

   return this.httpClient.get<number>(url);
  }

  changePassword(id,oldPassword, newPassword, confirmPassword): Observable<string>{


    let url = 'http://localhost:9002/'+id+'/changepassword/'+oldPassword+'/'+newPassword+'/'+confirmPassword;
    return this.httpClient.put<string>(url,"");


  }
  dummy(): Observable<Product> {
    let url = 'http://localhost:9002/products';

    return this.httpClient.get<Product>(url);


  }

  getid() {
    return this.id;
  }

  setid(id: number) {
    this.id = id;
  }
}
