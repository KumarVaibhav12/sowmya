import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './customer';
import { Product } from './Product'
import { templateJitUrl } from '@angular/compiler';


@Injectable({
  providedIn: 'root'
})
export class CustserviceService {
  id:number;

ha:string;
  constructor(private httpClient: HttpClient) { }
  login(uName, pwd): Observable<number> {
    let url = 'http://localhost:9003/login/' + uName + '/' + pwd;

   return this.httpClient.get<number>(url);
  }

  changePassword(id,oldPassword, newPassword, confirmPassword): Observable<string>{


    let url = 'http://localhost:9003/'+this.id+'/changepassword/'+oldPassword+'/'+newPassword+'/'+confirmPassword;
    return this.httpClient.put<string>(url,"");


  }
  getMen(): Observable<Product> {
    let url = 'http://localhost:9003/productsMen';

    return this.httpClient.get<Product>(url);


  }
  getWomen(): Observable<Product> {
    let url = 'http://localhost:9003/productsWomen';

    return this.httpClient.get<Product>(url);


  }
  getKids(): Observable<Product> {
    let url = 'http://localhost:9003/productsKids';

    return this.httpClient.get<Product>(url);


  }
  getAllCartItems():Observable<Product>{
    let url='http://localhost:9003/'+this.id+'/Cart';
    return this.httpClient.get<Product>(url);
  }
  addToCart(pro):Observable<boolean>
  {
    
    return this.httpClient.post<boolean>('http://localhost:9003/'+this.id+'/addtocart',pro);
    }

    getAllWishlistItems():Observable<Product>{
      let url='http://localhost:9003/'+this.id+'/Wishlist';
      return this.httpClient.get<Product>(url);
    }
    addToWishlist(prod:Product):Observable<boolean>
  {
    return this.httpClient.post<boolean>('http://localhost:9003/'+this.id+'/addtoWishlist',prod);
    }
    search(item):Observable<Product>{
this.ha=item;
      let url='http://localhost:9003/search/'+item;
      return this.httpClient.get<Product>(url);
    }
    
    sort(s1):Observable<Product>{
      
      let url='http://localhost:9003/search/'+this.ha+'/sort'+s1;
      return this.httpClient.get<Product>(url);
    }
    generateInvoice(prod:Product):Observable<boolean>
  {
    return this.httpClient.post<boolean>('http://localhost:9003/'+this.id+'/buyNow',prod);
    }
    RemoveFromWishlist(pro_id:number):Observable<boolean>{
      let url='http://localhost:9003/'+this.id+'/'+pro_id+'/removefromwishlist';
      return this.httpClient.delete<boolean>(url);
    };

    RemoveFromCart(prod_id:number):Observable<boolean>{
      let url='http://localhost:9003/'+this.id+'/'+prod_id+'/removefromcart';
      return this.httpClient.delete<boolean>(url);
    }
    
  getid() {
    return this.id;
  }

  setid(id: number) {
    this.id = id;
  }
}
