package com.cg.service;

import java.util.List;

import com.cg.bean.Cart;
import com.cg.bean.Product;
import com.cg.bean.Wishlist;

public interface CustService {
	 public int loginByUsername(String uName, String pwd);
	 public boolean changePwd( int id,String oldpassword, String newpassword, String confirmpassword);
	 public void addToCart(Product pro,int id) ;
	 List<Cart> getAllCartItems(int id);
	 List<Wishlist> getAllItems(int id);
	public void  addToWishlist(Product pro, int id);
	public void removeFromWishlist(int id,int id1);
	public void removeFromCart(int id, int pid);
	public void buyNow(Product pro,int id);
	
}
