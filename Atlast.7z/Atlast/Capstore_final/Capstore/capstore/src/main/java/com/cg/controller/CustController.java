package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Cart;
import com.cg.bean.Product;
import com.cg.bean.Wishlist;
import com.cg.service.CustService;
import com.cg.service.ProdService;
@CrossOrigin("http://localhost:4200")
@RestController
public class CustController {
	@Autowired
	CustService ser;
	@Autowired
	ProdService pSer;
	  @RequestMapping(value = "/login/{username}/{password}")
  	public int  lo(@PathVariable String username,@PathVariable String password) {
  		return ser.loginByUsername(username, password);
  	}
	
	  @RequestMapping(value ="/productsMen")
	  	public List<Product> productM() {
	  		return pSer.getAllProdsM();
	  	}
	 @RequestMapping(value = "/productsWomen")
	  	public List<Product> productW() {
	  		return pSer.getAllProdsW();
	  	}
	  @RequestMapping(value = "/productsKids")
	  	public List<Product> productK() {
	  		return pSer.getAllProdsK();
	  	}
	  @RequestMapping(value = "/{id}/Cart")
	  	public List<Cart> getAllCartItems(@PathVariable int id) {
	  		return ser.getAllCartItems(id);
	  	}
	  @RequestMapping(value = "/{id}/addtocart", method = RequestMethod.POST)
		public void addToCart(@RequestBody Product pro ,@PathVariable int id) {
			 ser.addToCart(pro,id);
		}
	  @RequestMapping(value = "/{id}/Wishlist")
	  	public List<Wishlist> getAllItems(@PathVariable int id) {
	  		return ser.getAllItems(id);
	  	}
	  @RequestMapping(value = "/{id}/addtoWishlist", method = RequestMethod.POST)
		public void addToWishlist(@RequestBody Product pro,@PathVariable int id) {
			 ser.addToWishlist(pro,id);
		}
	  @RequestMapping(value = "/{id}/buyNow", method = RequestMethod.POST)
		public void buyNow(@RequestBody Product pro, @PathVariable int id) {
			 ser.buyNow(pro,id);
		}
 @DeleteMapping(value = "/{id}/{pid}/removefromwishlist")
	  	public void removeFromWishlist(@PathVariable int id,@PathVariable int pid) {
	  		 ser.removeFromWishlist(id,pid);
	  	}
	  
 @DeleteMapping(value = "/{id}/{pid}/removefromcart")
	public void removeFromCart(@PathVariable int id,@PathVariable int pid) {
		 ser.removeFromCart(id,pid);
	}
 
	  @RequestMapping(value = "/search/{item}")
	  	public List<Product> getSearchItems(@PathVariable String item) {
	  		return pSer.getSearchItems(item);
	  	}
	  
	  @RequestMapping(value = "/search/{item}/sortByPrice")
	  	public List<Product> getSort(@PathVariable String item) {
	  		return pSer.getSort(item);
	  	}
	  
	  
	  @PutMapping(value="/{id}/changepassword/{oldpassword}/{newpassword}/{confirmpassword}")
	  public String changepwd(@PathVariable int id,@PathVariable String oldpassword,@PathVariable String newpassword,@PathVariable String confirmpassword) {
		
		 if(ser.changePwd(id, oldpassword, newpassword, confirmpassword)==true) {
			 
			return "Successfully changed";
			
			 
		 }
		 
		 return "Something Went Wrong";
		  
	  }
	  
	  
}
