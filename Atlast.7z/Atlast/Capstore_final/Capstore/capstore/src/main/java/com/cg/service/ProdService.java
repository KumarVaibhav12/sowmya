package com.cg.service;

import java.util.List;

import com.cg.bean.Cart;
import com.cg.bean.Product;

public interface ProdService {
	
	List<Product> getAllProdsM();
	List<Product> getAllProdsW();
	List<Product> getAllProdsK();
	List<Product> getSearchItems(String item);
	List<Product> getSort(String item);

}
