import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from './employee';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private httpClient: HttpClient) { 
    this.getemployeeDetails().subscribe(data => this.employeeList = data);
  }
  employeeList: Array<Employee> = [];

  url: string = "/assets/employee.json";


  getemployeeDetails(): any {
    return this.httpClient.get<Employee>(this.url);
  }
  setemployeeDetails(employee:Employee){
    this.employeeList.push(employee);
  }
  updateemployeeDetails(employee: Employee) {
    for (let b of this.employeeList) {
      if (employee.Id == b.Id) {
        b.Id = employee.Id;
        b.EmployeeName = employee.EmployeeName;
        b.Email = employee.Email;
        b.Phone = employee.Phone;
      }
    }
    console.log(this.employeeList);
  }
  deleteemployee(Id: number): void {
    let i = 0;
    for (let e of this.employeeList) {
      if ( e.Id== Id) {
        console.log("employee id " + e.Id);
        console.log(this.employeeList.splice(i, 1));
      }
      i++;
    }

  }

}

