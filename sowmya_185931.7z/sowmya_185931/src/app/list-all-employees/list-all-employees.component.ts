import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-list-all-employees',
  templateUrl: './list-all-employees.component.html',
  styleUrls: ['./list-all-employees.component.css']
})
export class ListAllEmployeesComponent implements OnInit {
  employeeList:any[];
  constructor(private employeeservice:EmployeeService) { 
  this.employeeList= this.employeeservice.employeeList;
  }
  ngOnInit() {
    this.employeeList= this.employeeservice.employeeList;
    
  }
  reload(){
    this.employeeList= this.employeeservice.employeeList;
  }

  flag=false;
EmployeeName;Id;Email;Phone;

bo:Employee=new Employee;
  changeFlag(b:Employee){
    this.flag=true;
    this.EmployeeName=b.EmployeeName;this.Id=b.Id;this.Email=b.Email;this.Phone=b.Phone;
    

  }
 edit
  (f){
   let b:Employee=new Employee;
  b=f;
  console.log(b);
  this.employeeservice.updateemployeeDetails(b);
  }

  delete(Id:number){
    this.employeeservice.deleteemployee(Id);
    this.employeeList= this.employeeservice.employeeList;
  }
}