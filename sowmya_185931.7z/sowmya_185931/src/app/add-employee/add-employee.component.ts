import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
 employeeList:any[];
 employee: Employee=new Employee();
 Idmsg:any;
 Namemsg:any;
 Emailmsg:any;
 Phonemsg:any;
  constructor(private employeeService:EmployeeService) { }

  ngOnInit() {
  }
  insert(data) {
    alert(`Id: ${data.Id} EmployeeName: ${data.EmployeeName} Email: ${data.Email} Phone: ${data.Phone}`);
    this.employee.Id = data.Id;
   
    this.employee.EmployeeName = data.EmployeeName;
   
    this.employee.Email= data.Email;
    this.employee.Phone = data.Phone;
    if(!data.Id)
    {
      this.Idmsg ="Employee id is required "
    }
    else{
      this.Idmsg=null;
    }
    if(!data.Namemsg)
    {
      this.Namemsg ="Employee name is required "
    }
    else{
      this.Namemsg=null;
    }
    if(!data.Emailmsg)
    {
      this.Emailmsg ="Employee mail is required "
    }
    else{
      this.Emailmsg=null;
    }
    if(!data.Phonemsg)
    {
      this.Phonemsg ="Employee phone is required "
    }
    else{
      this.Phonemsg=null;
    }
    console.log(this.employee);
    this.employeeService.setemployeeDetails(this.employee);
  }
  show(data): void {
    alert(`employee Added\nId: ${data.Id} EmployeeName: ${data.EmployeeName} Email: ${data.Email} Phone: ${data.Phone}`);
  }
}
