package com.cg.service;

import java.util.List;

import com.cg.bean.Cart;
import com.cg.bean.Product;
import com.cg.bean.Wishlist;

public interface CustService {
	 public int loginByUsername(String uName, String pwd);
	 public boolean changePwd( int id,String oldpassword, String newpassword, String confirmpassword);
	 public void addToCart(Cart cart) ;
	 List<Cart> getAllCartItems();
	 List<Wishlist> getAllItems();
	public void  addToWishlist(Wishlist wishlist);
	
}
