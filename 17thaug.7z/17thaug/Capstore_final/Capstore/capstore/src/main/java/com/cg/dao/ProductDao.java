package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cg.bean.Product;
@Repository
public interface ProductDao extends JpaRepository<Product, Integer>{
		
	 @Query(value="SELECT * FROM pro WHERE prod_category=:u",nativeQuery=true)
	    List<Product> getMen(@Param("u") String Men);
	 @Query(value="SELECT * FROM pro WHERE prod_category=:u",nativeQuery=true)
	 List<Product> getWomen(@Param("u") String Women);
	 @Query(value="SELECT * FROM pro WHERE prod_category=:u",nativeQuery=true)
	 	List<Product> getKids(@Param("u") String Kids);
	 @Query(value="SELECT * FROM pro WHERE prod_name=:u",nativeQuery=true)
	 	List<Product> getItems(@Param("u") String item);

	
}
