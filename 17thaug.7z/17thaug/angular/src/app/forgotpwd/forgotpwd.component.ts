import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgotpwd',
  templateUrl: './forgotpwd.component.html',
  styleUrls: ['./forgotpwd.component.css']
})
export class ForgotpwdComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
forgotpwd(email){

  

}



}
