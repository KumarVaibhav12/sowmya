import { Component, OnInit } from '@angular/core';
import {CustserviceService} from '../custservice.service';
import { Router } from '@angular/router';
import { Product } from '../Product';
@Component({
  selector: 'app-kids',
  templateUrl: './kids.component.html',
  styleUrls: ['./kids.component.css']
})
export class KidsComponent implements OnInit {
  prod:Product;
  constructor(private router: Router, private userService: CustserviceService) {

  }
  ngOnInit() {
    this.getKids();

    
  }
  getKids() {
   
    this.userService.getKids().subscribe(data => {
     this.prod=data;
    })
  };
  addToCart(pro){
    this.userService.addToCart(pro).subscribe(result=>{
      console.log(result);
    });
    }
    addToWishlist(pro){
      this.userService.addToWishlist(pro).subscribe(result=>{
        console.log(result);
      });
      }
}