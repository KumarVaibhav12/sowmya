import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import{LoginComponent} from './login/login.component'
import{ForgotpwdComponent} from './forgotpwd/forgotpwd.component';
import{ChangepwdComponent} from './changepwd/changepwd.component'
import{MainComponent}from './main/main.component';
import{MenComponent} from './men/men.component';
import {WomenComponent} from './women/women.component';
import{KidsComponent} from './kids/kids.component';
import {WishlistComponent} from './wishlist/wishlist.component';
import {CartComponent} from './cart/cart.component';
import {ProfileComponent} from './profile/profile.component';
import { from } from 'rxjs';

const routes: Routes = [

 { path: 'ForgotPassword', component: ForgotpwdComponent},
 { path: 'loginComponent', component: LoginComponent},
 { path:'',redirectTo:'loginComponent', pathMatch:'full' },
  {path: 'ChangePassword', component: ChangepwdComponent},
  {path:'Main',component:MainComponent},
  {path:'Men',component:MenComponent},
  {path:'Women',component:WomenComponent},
  {path:'Kids',component:KidsComponent},
  {path:'Wishlist',component:WishlistComponent},
  {path:'Cart',component:CartComponent},
  {path:'Profile',component:ProfileComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
