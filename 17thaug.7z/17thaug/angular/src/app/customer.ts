export class Customer{
uName: string;
pwd:string;





}