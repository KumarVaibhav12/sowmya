package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Cart;
import com.cg.bean.Product;
import com.cg.dao.ProductDao;
@Service
public class ProdServiceImpl implements ProdService {
	@Autowired
	ProductDao pDao;
	@Override
	public List<Product> getAllProdsM() {
		 List<Product> ls = pDao.getMen("Men");
		return ls;
	}
	@Override
	public List<Product> getAllProdsW() {
		 List<Product> ls = pDao.getWomen("Women");
		return ls;
	}
	@Override
	public List<Product> getAllProdsK() {
		List<Product> ls = pDao.getKids("kids");
		return ls;
	}
	@Override
	public List<Product> getSearchItems(String item) {
		List<Product> ls = pDao.getItems(item);
		return ls;
	}
	@Override
	public List<Product> getSort(String item) {
		List<Product> ls = pDao.getSort(item);
		return ls;
	}
	@Override
	public List<Product> getSort1(String item) {
		List<Product> ls = pDao.getSort(item);
		return ls;
	}
	

}
