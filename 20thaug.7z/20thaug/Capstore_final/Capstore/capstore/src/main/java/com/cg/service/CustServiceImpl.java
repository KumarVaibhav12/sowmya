package com.cg.service;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Exception.CapStoreException;
import com.cg.bean.Cart;
import com.cg.bean.Customer;
import com.cg.bean.Invoice;
import com.cg.bean.Product;
import com.cg.bean.Wishlist;
import com.cg.dao.CartDao;
import com.cg.dao.CustDao;
import com.cg.dao.InvoiceDao;
import com.cg.dao.WishlistDao;

@Service
public class CustServiceImpl implements CustService {
	@Autowired
	CustDao dao;
	@Autowired
	CartDao cartDao;
	@Autowired
	WishlistDao wishlistDao;
	@Autowired
	InvoiceDao invoicedao;
	@Autowired
	PwdEncryptServiceImpl pe;

	@Override
	public int loginByUsername(String uName, String pwd) throws CapStoreException {
		try {
			Customer cust = dao.getCustomerByUsername(uName);
			if(pe.decrypt(cust.getPwd()).equals(pwd))
				return cust.getCust_id();
			else {
				throw new CapStoreException("Please enter valid username and password");

			}
		}
		catch (Exception ex) {
			throw new CapStoreException("Please enter valid username and password");
		}
	}

	@Override
	public boolean changePwd(int id, String oldpassword, String newpassword, String confirmpassword) {
		Customer cust = dao.getOne(id);
		if (pe.decrypt(cust.getPwd()).equals(oldpassword)) {
			if (newpassword.equals(confirmpassword)) {
				cust.setPwd(pe.encrypt(newpassword));
				dao.save(cust);
				return true;
			}
		}
		return false;
	}

	public void addToCart(Product pro, int id) {
		System.out.println(id);
		System.out.println(pro);
		Cart c = new Cart();
		c.setCust_id(id);
		c.setProd_id(3);
		c.setProd_desc(pro.getProd_desc());
		c.setProd_img_link(pro.getProd_img_link());
		c.setProd_name(pro.getProd_name());
		c.setProd_price(pro.getProd_price());
		System.out.println(c);
		cartDao.save(c);
	}

	@Override
	public List<Cart> getAllCartItems(int id) {
		return cartDao.findAll(id);
	}

	@Override
	public void addToWishlist(Product pro, int id) {

		System.out.println(id);
		Wishlist wishlist = new Wishlist();
		wishlist.setCust_id(id);
		wishlist.setProd_id(pro.getProd_id());
		wishlist.setProd_desc(pro.getProd_desc());
		wishlist.setProd_img_link(pro.getProd_img_link());
		wishlist.setProd_name(pro.getProd_name());
		wishlist.setProd_price(pro.getProd_price());
		wishlistDao.save(wishlist);

	}

	@Override
	public List<Wishlist> getAllItems(int id) {
		return wishlistDao.findAll(id);

	}

	@Override
	public void removeFromWishlist(int id, int id1) {
		wishlistDao.deleteByImg_link(id, id1);

	}

	@Override
	public void removeFromCart(int id, int pid) {
		cartDao.deleteByImg_link(id, pid);

	}

	@Override
	public void buyNow(Product pro, int id) {
		System.out.println(pro);
		System.out.println(id);
		Invoice inv = new Invoice();
		inv.setCust_id(id);
		inv.setProd_id(pro.getProd_id());
		System.out.println(inv.getProd_id());
		inv.setProd_desc(pro.getProd_desc());
		inv.setProd_img_link(pro.getProd_img_link());
		inv.setProd_name(pro.getProd_name());
		inv.setProd_price(pro.getProd_price());
		System.out.println(inv);

		invoicedao.save(inv);

	}

	@Override
	public List<Invoice> getInvoice(int id) {

		return invoicedao.findAll(id);
	}

	@Override
	public double getInvoiceb(int id) {
		return invoicedao.sum(id);
	}

	@Override
	public boolean forgotPwd(String uName, String newpassword, String confirmpassword) {

		Customer cust = dao.getCustomerByUsername(uName);
		if (cust.getuName().equals(uName)) {
			if (newpassword.equals(confirmpassword)) {

				cust.setPwd(pe.encrypt(newpassword));
				dao.save(cust);
				return true;
			}
		}
		return false;
	}

	@Override
	public Optional<Customer> getCustById(int id) {
		return dao.findById(id);
	}

}
