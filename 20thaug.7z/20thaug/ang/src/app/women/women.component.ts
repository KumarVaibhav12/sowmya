import { Component, OnInit } from '@angular/core';
import {CustserviceService} from '../custservice.service';
import { Router } from '@angular/router';
import { Product } from '../Product';

@Component({
  selector: 'app-women',
  templateUrl: './women.component.html',
  styleUrls: ['./women.component.css']
})
export class WomenComponent implements OnInit {
  prod:Product;
  prod1:Product;
  constructor(private router: Router, private userService: CustserviceService) {

  }
  ngOnInit() {
    this.getWomen();

    
  }
  getWomen() {
   
    this.userService.getWomen().subscribe(data => {
     this.prod=data;
    })
  };
  search(item){
    this.userService.search(item).subscribe(data => {
      this.prod=data;
     }
     )
 console.log(this.prod)
  };
  sort(str){
    if(str=="LOW to HIGH"){
      str="lth"
    }
    else if(str=="HIGH to LOW"){
      str="htl"
    }
    this.userService.sort(str).subscribe(data => {
      this.prod=data;
     }
     )
     console.log(this.prod)
  };
  
  addToCart(pro){
    this.userService.addToCart(pro).subscribe(result=>{
      console.log(result);
    });
    }
    addToWishlist(pro){
      this.userService.addToWishlist(pro).subscribe(result=>{
        console.log(result);
      });
      }

}

