import { Component, OnInit } from '@angular/core';
import {CustserviceService} from '../custservice.service';
import { Router } from '@angular/router';
import { Product } from '../Product';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
prod1:Product;
prod2:Product;
item:string
  constructor(private router: Router, private userService: CustserviceService) { }

  ngOnInit() {

  }

  search(item){
    this.userService.search(item).subscribe(data => {
      this.prod1=data;
     }
     )
 console.log(this.prod1)
  };
  sort(str){
    this.userService.sort(str).subscribe(data => {
      this.prod1=data;
     }
     )
     console.log(this.prod1)
  };



}
