import { Component, OnInit } from '@angular/core';
import {CustserviceService} from '../custservice.service';
import { Router } from '@angular/router';
import { Customer } from '../customer';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
data:Customer;
custo:Customer;
  constructor(private router: Router, private userService: CustserviceService) {

  }
  ngOnInit() {
    this.getCustomerDetails();
  }

  getCustomerDetails(){
    this.userService.getCustomerDetails().subscribe(data =>{      
      this.custo=data;
    })
    };
  }


