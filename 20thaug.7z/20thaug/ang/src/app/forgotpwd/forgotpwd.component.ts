import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import{CustserviceService} from '../custservice.service'

@Component({
  selector: 'app-forgotpwd',
  templateUrl: './forgotpwd.component.html',
  styleUrls: ['./forgotpwd.component.css']
})
export class ForgotpwdComponent implements OnInit {
  message:string

  constructor(private router: Router,private userService:CustserviceService) { }

  ngOnInit() {
  }
forgotpwd(email){
  
  alert("SENT SUCCESFULLY")
  this.router.navigate(['/ForgotPassword']);
  

}

forgotPassword(uName,newPassword,confirmPassword){
  this.userService.forgotPassword(uName ,newPassword,confirmPassword).subscribe(data=>
    {
      this.message=data
      
    });
    alert("CHANGED SUCCESFULLY")
  this.router.navigate(['/loginComponent']);
      }
    

}
