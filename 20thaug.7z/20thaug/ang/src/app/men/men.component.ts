import { Component, OnInit } from '@angular/core';
import {CustserviceService} from '../custservice.service';
import { Router } from '@angular/router';
import { Product } from '../Product';

@Component({
  selector: 'app-men',
  templateUrl: './men.component.html',
  styleUrls: ['./men.component.css']
})
export class MenComponent implements OnInit {
  prod:Product;
  prod1:Product;
  constructor(private router: Router, private userService: CustserviceService) {

  }
  ngOnInit() {
    this.getMen();

    
  }
  getMen() {
   
    this.userService.getMen().subscribe(data => {
     this.prod=data;
    })
  };
  
addToCart(pro){
this.userService.addToCart(pro).subscribe(result=>{
  console.log(result);
});
console.log(pro)
}

addToWishlist(pro){
  this.userService.addToWishlist(pro).subscribe(result=>{
    console.log(result);
  });
  }
search(item){
  this.userService.search(item).subscribe(data => {
    this.prod=data;
   }
   )
console.log(this.prod)
};
sort(str){
  this.userService.sort(str).subscribe(data => {
    this.prod=data;
   }
   )
   console.log(this.prod)
};

}
