import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { Router } from '@angular/router';
 import {CustserviceService } from '../custservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 
  
  constructor(private router: Router, private userService:CustserviceService) { 
    
  }
    
  ngOnInit() {
 
  }

  login(uName,pwd){
    this.userService.login(uName,pwd).subscribe(data=>{
      this.userService.setid(data);
      alert(this.userService.getid())
      this.router.navigate(['/homecomponent']);
      },error=>{alert("Wrong credentials")});
  };

}
