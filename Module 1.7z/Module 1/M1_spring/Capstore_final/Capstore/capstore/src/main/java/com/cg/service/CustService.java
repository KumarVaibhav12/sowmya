package com.cg.service;

public interface CustService {
	 public int loginByUsername(String uName, String pwd);
}
