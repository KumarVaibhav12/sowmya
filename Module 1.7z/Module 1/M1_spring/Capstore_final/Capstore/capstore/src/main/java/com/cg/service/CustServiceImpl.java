package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Customer;
import com.cg.dao.CustDao;
@Service
public class CustServiceImpl implements CustService{
	@Autowired
  CustDao dao;
	@Override
	public int loginByUsername(String uName, String pwd) {
		
		Customer cust=dao.getCustomerByUsername(uName);
		 if(cust.getPwd().equals(pwd))
		        return cust.getId();
		return 0;
	}

}
