package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.service.CustService;
@CrossOrigin("http://localhost:4200")
@RestController
public class CustController {
	@Autowired
	CustService ser;
	  @RequestMapping(value = "/login/{username}/{password}")
  	public int  lo(@PathVariable String username,@PathVariable String password) {
  		return ser.loginByUsername(username, password);
  	}
}
