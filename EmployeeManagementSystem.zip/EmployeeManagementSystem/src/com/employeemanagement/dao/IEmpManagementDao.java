package com.employeemanagement.dao;
import com.employeemanagement.bean.Employee;
public interface IEmpManagementDao {
public  int addEmployee(Employee emp);
	
	public  void deleteById();
	
	public  void viewAllEmployees();
	
	public  void viewById();
	
	public  void updatePassword();
	
	public  void updateName();
	

}
