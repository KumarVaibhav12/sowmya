package com.employeemanagement.service;
import java.util.Random;

import com.employeemanagement.bean.Employee;
import com.employeemanagement.dao.*;
public class TrainerServiceImpl implements IEmployeeManagementService {

	IEmpManagementDao iemp=null;
	private int generateEmpid(){
		Random rd=new Random();
		return rd.nextInt(100000);
	}
	public int addEmployee(Employee emp) {
		emp.setEmpid(generateEmpid());//modicf
		//pass to dao
		iemp=new EmpManagementDaoImpl();
		return iemp.addEmployee(emp);
	}

	
	public void deleteById() {
		// TODO Auto-generated method stub
		
	}

	
	public void viewAllEmployees() {
		// TODO Auto-generated method stub
		
	}

	
	public void viewById() {
		// TODO Auto-generated method stub
		
	}

	
	public void updatePassword() {
		// TODO Auto-generated method stub
		
	}

	
	public void updateName() {
		// TODO Auto-generated method stub
		
	}

}
