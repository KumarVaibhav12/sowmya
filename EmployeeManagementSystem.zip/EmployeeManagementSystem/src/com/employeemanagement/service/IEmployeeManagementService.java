package com.employeemanagement.service;
import com.employeemanagement.bean.*;

public interface IEmployeeManagementService {
	public  int addEmployee(Employee emp);
	

	public  void deleteById();
	
	public  void viewAllEmployees();
	
	public  void viewById();
	
	public  void updatePassword();
	
	public  void updateName();
	
}
