package com.capgemini.bank.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.bank.model.Bank;
import com.capgemini.bank.service.BankService;
import com.capgemini.bank.service.BankServiceImpl;

public class Main {
public static void main(String[] args) 
  {
	BankService service=new BankServiceImpl();
	Scanner sc=new Scanner(System.in);
	int i;
     do{
	int choice;
	System.out.println("Welcome to xyz Bank");
	System.out.println("Enter your choice");
	System.out.println("1.create Account\n2. Show Balance\n3. Deposit\n4. Withdraw\n5.Fund Transfer\n 6. Print Transactions");
	choice=sc.nextInt();
	switch(choice){
	case 1:
		
		service.createAccount();
		break;
	case 2:
		
	System.out.println(service.showBalance());
		break;
	case 3:
		
		service.deposit();
		break;
	case 4:
		
		service.withDraw();
		break;
	case 5:
		 service.fundTransfer();
		break;
	case 6:
		List<String> l1=new ArrayList<String>();
		l1=service.printTransactions();
		Iterator<String> itr=l1.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
		break;
		default:
	}
     
	System.out.println("Do you want to 1.Continue\t 2.End");

	i=sc.nextInt();
     }
	while(i==1);
}
}
