package com.capgemini.bank.service;
import java.util.List;

import com.capgemini.bank.model.Bank;
import com.capgemini.bank.ui.*;
public interface BankService {
public void createAccount();
Bank showBalance();
void deposit();
void withDraw();
 void fundTransfer();
 List<String> printTransactions();


}
