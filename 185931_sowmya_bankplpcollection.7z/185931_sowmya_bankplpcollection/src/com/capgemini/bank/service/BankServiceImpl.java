package com.capgemini.bank.service;

import java.util.List;
import java.util.Scanner;

import com.capgemini.bank.dao.BankDao;
import com.capgemini.bank.dao.BankDaoImpl;
import com.capgemini.bank.model.Bank;

public class BankServiceImpl implements BankService {
public static BankDao dao=new BankDaoImpl(); 
Scanner sc=new Scanner(System.in);
@Override
public void createAccount() {
	int i;
	Bank b=new Bank();
	do{
	System.out.println("Enter the name");
   b.setName(sc.next());
   i=b.checkName();
	}
	while(i==1);
 System.out.println("set the pin to the account");
 b.setPin(sc.nextInt());
	System.out.println("Enter the amount to be deposited");
 b.setBalance(sc.nextInt());
 b.setAccountno();
 System.out.println("Account created successfully");
	dao.createBankAccount(b);
}
@Override
public Bank showBalance() {
	double i,accountno;
	int k;
	int pin;
	Bank b=new Bank();
	do{
	System.out.println("enter account no");
	 accountno = sc.nextDouble();
	i=dao.checkAccountNo(accountno);
	}
	while(i==1);
	do{
	System.out.println("enter the pin");
	 pin=sc.nextInt();
	k=dao.pin1(pin);
	}
	while(k==1);
	return dao.showAccountBalance(accountno,pin);
}
@Override
public void deposit() {
	double i,accountno;
	Bank b=new Bank();
	do{
	System.out.println("enter the account no");
	 accountno = sc.nextDouble();
	 i=dao.checkAccountNo(accountno);
	}
	while(i==1);
	System.out.println("enter the amount to be depoist:");
	int amt = sc.nextInt();
	dao.deposit(accountno, amt);
}

@Override
public void withDraw() {
	double i,accountno;
	int pin;
	Bank b=new Bank();
	do{
	System.out.println("enter the account no");
	 accountno = sc.nextDouble();
	 i=dao.checkAccountNo(accountno);
	}
	while(i==1);
	System.out.println("enter the amount to be withdrawn:");
	int amt = sc.nextInt();
	dao.withDraw(accountno, amt);
}
@Override
public void fundTransfer() {
	double i,accountno;
	Bank b=new Bank();
	do{
	System.out.println("enter the account no");
	 accountno = sc.nextDouble();
	 i=dao.checkAccountNo(accountno);
	}
	while(i==1);
do{
	System.out.println("enter the account number to which amount has to be transferred:");
	 accountno = sc.nextDouble();
	i=dao.checkAccountNo(accountno);
}
while(i==1);
	System.out.println("enter the amount to be transferred");
	int amt = sc.nextInt();
	double acctto = 0;
	dao.fundTransfer(accountno, acctto, amt);
}
@Override
public List<String> printTransactions() {
	double i,accountno;
	Bank b=new Bank();
	do{
	System.out.println("enter the account no");
	 accountno = sc.nextDouble();
	 i=dao.checkAccountNo(accountno);
	}
	while(i==1);
	
	return dao.printTransction(accountno);
	}



}




