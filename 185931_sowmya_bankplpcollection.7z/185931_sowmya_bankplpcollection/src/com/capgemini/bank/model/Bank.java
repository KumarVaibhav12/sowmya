package com.capgemini.bank.model;

import java.util.ArrayList;
import java.util.List;

public class Bank {

		
		// TODO Auto-generated method stub
		private String name;
		private int pin;
		private int balance;
		private double Accountno;
		private static double acctno=1000;
		private List<String> list = new ArrayList<String>();
		
		
		
		

		public List<String> getList() {
			return list;
		}

		

		public  double getAcctno() {
			return acctno;
		}
		
		public void setName(String name) {
				this.name=name;
				
		}
		public int getPin() {
			return pin;
		}
		public void setPin(int pin) {
			this.pin = pin;
		}
		public int getBalance() {
			return balance;
		}
		public void setBalance(int balance) {
			this.balance = balance;
		}
		public double getAccountno() {
			return Accountno;
		}
		public void setAccountno() {
			Accountno = ++acctno;
		}
		
		@Override
		public String toString() {
			return "Bank [name=" + name + ", pin=" + pin + ", balance=" + balance + ", Accountno=" + Accountno + "]";
		}
		public Bank(String name, int pin, int balance, double accountno) {
			super();
			this.name = name;
			this.pin = pin;
			this.balance = balance;
			Accountno = accountno;
		}
		public Bank() {
			super();
			// TODO Auto-generated constructor stub
		}

		public void setList(String string) {
			// TODO Auto-generated method stub
			list.add(string);
			this.list = list;
			
		}
		public int checkName(){
			if(name.charAt(0)>65 && name.charAt(0)<90 ){
				this.name=name;
				return 0;
				}
			else
			{
				System.out.println("Enter first letter as capital");
			}
			return 1;
		}
		
}

	