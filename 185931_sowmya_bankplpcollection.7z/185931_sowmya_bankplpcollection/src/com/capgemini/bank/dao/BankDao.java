package com.capgemini.bank.dao;

import java.util.List;

import com.capgemini.bank.model.Bank;

public interface BankDao {
public void createBankAccount(Bank b);
public int pin1(int pin);public double checkAccountNo(double accountno);
public Bank showAccountBalance(double accountno,int pin);
void deposit(double accountno, int amt);
void withDraw(double accountno, int amt);
void fundTransfer(Double accountno, double acctto, int amt);
List<String> printTransction(double Accountno);




}
