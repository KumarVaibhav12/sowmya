package com.capgemini.bank.dao;


import java.util.ArrayList;
import java.util.List;

import com.capgemini.bank.model.Bank;


public class BankDaoImpl implements BankDao
{
	 static List<Bank> list=new ArrayList<Bank>();
	static{
		Bank b1 = new Bank("sowmya",123,50000,1000);
		Bank b2 = new Bank("uday",124,10000,1222);
		Bank b3 = new Bank("maeesha",125,12556,1366);
		Bank b4 = new Bank("meghana",126,25542,1566);
		list.add(b1);
		list.add(b2);
		list.add(b3);
		list.add(b4);	
		
		}

	@Override
	public void createBankAccount(Bank b) {
	list.add(b);
	System.out.println(b);
	}
	@Override
	public Bank showAccountBalance(double accountno,int pin) {
		Bank b=new Bank();
		for(Bank b1:list)
		{
		if(b1.getAccountno()==accountno)
		{
			b=b1;
			break;
		}
		}
		
		return b;		
	}
	@Override
	public void deposit(double accountno, int amt) {
		Bank b=new Bank();
		for(Bank b1:list){
		if(b1.getAccountno()==accountno)
		{
			b=b1;
			break;
		}
		}
		b.setBalance(b.getBalance()+amt);
		System.out.println("amount successfully deposited");
		System.out.println("new balance:"+b.getBalance());
		b.setList(+amt+ " rupees successfully deposited");
		
	}
	@Override
	public void withDraw(double accountno, int amt) {
		Bank b=new Bank();
		for(Bank b1:list){
		if(b1.getAccountno()==accountno)
		{
			b=b1;
			break;
		}
		}
		if(b.getBalance()>amt){
			b.setBalance(b.getBalance()-amt);
			System.out.println("amount sucessfully withdrawn");
			System.out.println(b.getBalance());
			b.setList(+amt+ " rupees Amount withrawn");
		}
		
	}
		
@Override
public void fundTransfer(Double accountno, double acctto, int amt) {
	Bank b=new Bank();
	for(Bank b1:list){
	if(b1.getAccountno()==accountno)
	{
		b=b1;
		break;
	}
	}
	Bank b2=new Bank();
	for(Bank bt:list){
		if(bt.getAccountno()==acctto)
		{
			b2=bt;
			break;
		}
			}
	if(b.getAccountno()!=b.getAcctno()){	
	
	if(b.getBalance()>amt){
			b.setBalance(b.getBalance()-amt);
		
			System.out.println("Amount successfull credited and deposited to required acccount no");
			System.out.println("new balance:"+b.getBalance());
			b2.setBalance(b.getBalance()+amt);
			b.setList(+amt+ "rupees Amount succcesfully transferred to required account:");
		}
		else
			System.out.println("Insufficient amount in your account");
	}
	else{
		System.out.println("acccounts are same and hence funds cannot be transferred");
	}
	}
@Override
public List<String> printTransction(double Accountno) {
	Bank b=new Bank();
	for(Bank b1:list)
	if(b1.getAccountno()== Accountno)
	{
		b=b1;
		break;
	}
	return b.getList();
	
	}
@Override
/*account number validation: It checks whether the user enter valid account number or not*/
public double checkAccountNo(double accountno) {
	int b = 0;
	for(Bank b1 : list) { 
		   if(b1.getAccountno()==accountno)
		   {
			   b=1;
			  return accountno;
		   }
		}
	if(b==0)
	{
		System.out.println("please enter a valid account number");
	}
return 1;

	
}
/* pin validation: It checks whether the user entered correct pin or not*/
@Override
public int pin1(int pin) {
	int c = 0;
	for(Bank b1 : list) { 
		   if(b1.getPin()==pin)
		   {
			   c=1;
			  return 0;
		   }
		}
	if(c==0)
	{
		System.out.println("please enter a valid pin");
	}
return 1;
}


	

}