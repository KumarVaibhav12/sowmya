package com.cg.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="pro")
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int prod_id;
	public String prod_name;
	public String prod_img_link;
	public String prod_desc;
	public double prod_price;
	public String prod_category;
	public int pro_views;
	public int pro_rating;
	
	
	
	public int getPro_views() {
		return pro_views;
	}
	public void setPro_views(int pro_views) {
		this.pro_views = pro_views;
	}
	public int getPro_rating() {
		return pro_rating;
	}
	public void setPro_rating(int pro_rating) {
		this.pro_rating = pro_rating;
	}
	public String getProd_category() {
		return prod_category;
	}
	public void setProd_category(String prod_category) {
		this.prod_category = prod_category;
	}
	public Product() {
		super();
	}
	public int getProd_id() {
		return prod_id;
	}
	public void setProd_id(int prod_id) {
		this.prod_id = prod_id;
	}
	public String getProd_name() {
		return prod_name;
	}
	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}
	public String getProd_img_link() {
		return prod_img_link;
	}
	public void setProd_img_link(String prod_img_link) {
		this.prod_img_link = prod_img_link;
	}
	public String getProd_desc() {
		return prod_desc;
	}
	public void setProd_desc(String prod_desc) {
		this.prod_desc = prod_desc;
	}
	public double getProd_price() {
		return prod_price;
	}
	public void setProd_price(double prod_price) {
		this.prod_price = prod_price;
	}
	@Override
	public String toString() {
		return "Product [prod_id=" + prod_id + ", prod_name=" + prod_name + ", prod_img_link=" + prod_img_link
				+ ", prod_desc=" + prod_desc + ", prod_price=" + prod_price + ", prod_category=" + prod_category + "]";
	}
	
	

}
