import { Component, OnInit } from '@angular/core';
import {CustserviceService} from '../custservice.service';
import { Router } from '@angular/router';
import { Product } from '../Product';

@Component({
  selector: 'app-opinion',
  templateUrl: './opinion.component.html',
  styleUrls: ['./opinion.component.css']
})
export class OpinionComponent implements OnInit {
prod:Product
  constructor(private router: Router, private userService: CustserviceService) { }

  ngOnInit() {
    this.invoice();
  
  }

invoice(){
  this.userService.invoice().subscribe(data => {
    this.prod=data;
})
};
opinion(q){
  console.log(q)
  console.log("asdasd")
}




}
