import { Component, OnInit } from '@angular/core';
import {CustserviceService} from '../custservice.service';
import { Router } from '@angular/router';
import { Product } from '../Product';
@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {
  prod:Product;
  constructor(private router: Router, private userService: CustserviceService) {

  }
  ngOnInit() {
    this.getAllWishlistItems();
  }
getAllWishlistItems(){
  this.userService.getAllWishlistItems().subscribe(data => {
    this.prod=data;
})
};


RemoveFromWishlist(pro_id:number){
  this.userService.RemoveFromWishlist(pro_id).subscribe(data => {
})
};
}
