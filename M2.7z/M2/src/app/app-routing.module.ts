import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { ListAllEmployeesComponent } from './list-all-employees/list-all-employees.component';


const routes: Routes = [
  {path:'emplist', component: ListAllEmployeesComponent},
  {path:'addemp', component:AddEmployeeComponent,
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
