export class Employee{
    Id:number;
    EmployeeName:String;
    Email:any;
    Phone:number;
}