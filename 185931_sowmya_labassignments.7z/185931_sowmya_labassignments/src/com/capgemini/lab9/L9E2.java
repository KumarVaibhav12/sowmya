package com.capgemini.lab9;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class L9E2 {
	static Map<Character,Integer> m= new HashMap<>();
	static int square=0;
	static Map<Character, Integer> countCharacter(char[] s)
	
	{
		
		for(char i : s)
		{
			int k=0;
			for(char j :s)
			{
				if(i==j)
				{
					++k;
				}
			}
			m.put(i,k);
		}
		return m;
		
	}
public static void main(String[] args) {
	String s = new String();
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter chars");
	s=sc.next();
	char[] s1 = new char[10];
	s1=s.toCharArray();
	System.out.println(countCharacter(s1));
	
}
}
