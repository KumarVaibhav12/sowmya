package com.capgemini.lab9;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class L9E3 {
	static Map<Integer,Integer> m= new HashMap<>();
	static int square=0;
	static Map<Integer, Integer> setSquares(int[] s)
	
	{
		for(int i:s)
		{
			square=i*i;
			m.put(i,square);
		}
		return m;
		
	}
public static void main(String[] args) {
	int[] s = new int[5];
	s[0]=2;
	s[1]=3;
	s[2]=4;
	s[3]=5;
	s[4]=6;
	
	System.out.println(setSquares(s));
	
	
}
}
