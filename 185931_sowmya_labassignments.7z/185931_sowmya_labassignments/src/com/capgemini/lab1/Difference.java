package com.capgemini.lab1;

import java.util.Scanner;

public class Difference {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
	    System.out.println("enter the value of n");
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		calculateDifference();
	}

	private static void calculateDifference() {
		// TODO Auto-generated method stub
		
	}

}
