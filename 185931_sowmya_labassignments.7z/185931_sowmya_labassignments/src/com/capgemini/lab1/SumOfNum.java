package com.capgemini.lab1;

import java.util.Scanner;

public class SumOfNum {
public static void main(String[] args) {
    int n;
    System.out.println("enter the value of n");
	Scanner sc=new Scanner(System.in);
	n=sc.nextInt();
	calculateSum(n);
	
	
}

private static int calculateSum(int n) {
	int i,sum=0;
	for( i=1;i<=n;i++){
		if(i%3==0||i%5==0){
		 sum = sum+i;
		}
	}System.out.println(sum);
	return sum;
}
}
